== Theme: BusinessGrow ==

* By One Page, http://www.inkthemes.com/

== Theme License & Copyright ==
One Page is distributed under the terms of the GNU GPL
One Page- Copyright 2013 One Page, inkthemes.com
custom.js, mobile-menu.js is distributed under the terms of the GNU GPL

== modernizr.custom.08171.js License & Copyright ==
Modernizr is available under the MIT license:
MIT License
Copyright (c) 2009�2013
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
License link: http://modernizr.com/license/

== Superfish Menu hoverIntent.js, superfish.js License & Copyright ==
Copyright 2013 jQuery Foundation and other contributors,
http://jquery.com

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
License Link: http://github.com/joeldbirch/superfish/blob/master/MIT-LICENSE.txt

License for images:
Slider Image:-

https://pixabay.com/en/typewriter-book-notebook-paper-801921/
https://pixabay.com/en/city-skyline-cityscape-night-1149931/


Team Member Image:-

https://pixabay.com/en/business-man-lawyer-man-1125324/
https://pixabay.com/en/alejandro-vergara-blanco-jurist-872557/
https://pixabay.com/en/andrew-ronalds-legislative-council-876138/
https://pixabay.com/en/businessman-man-portrait-male-805769/